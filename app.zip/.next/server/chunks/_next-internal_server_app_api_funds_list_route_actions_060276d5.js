module.exports=[11643,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_list_route_actions_060276d5.js.map