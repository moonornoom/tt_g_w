module.exports=[58776,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_history_route_actions_d15d6680.js.map