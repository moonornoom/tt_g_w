module.exports=[33290,a=>{"use strict";var b=a.i(81332);function c({children:a}){return(0,b.jsx)("html",{lang:"zh-CN",children:(0,b.jsx)("body",{className:"bg-bg-page text-text-primary antialiased",children:a})})}a.s(["default",()=>c,"metadata",0,{title:"基金对比工具",description:"中国公募基金数据查询和对比工具"}])}];

//# sourceMappingURL=app_layout_tsx_271801d7._.js.map