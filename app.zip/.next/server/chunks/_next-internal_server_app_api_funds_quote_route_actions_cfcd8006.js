module.exports=[45381,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_quote_route_actions_cfcd8006.js.map