var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/quote/route.js")
R.c("server/chunks/[externals]_next_dist_b01ab6e1._.js")
R.c("server/chunks/[root-of-the-server]__8ecb8e44._.js")
R.c("server/chunks/[root-of-the-server]__9b703b72._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_quote_route_actions_cfcd8006.js")
R.m(43155)
module.exports=R.m(43155).exports
