var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/list/route.js")
R.c("server/chunks/[root-of-the-server]__45af125c._.js")
R.c("server/chunks/[root-of-the-server]__8ecb8e44._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_list_route_actions_060276d5.js")
R.m(4193)
module.exports=R.m(4193).exports
