var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/history/route.js")
R.c("server/chunks/[root-of-the-server]__dc9e018f._.js")
R.c("server/chunks/[root-of-the-server]__8ecb8e44._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_history_route_actions_d15d6680.js")
R.m(58780)
module.exports=R.m(58780).exports
