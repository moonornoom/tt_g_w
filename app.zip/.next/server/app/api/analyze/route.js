var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/analyze/route.js")
R.c("server/chunks/[root-of-the-server]__0dbc1f56._.js")
R.c("server/chunks/[root-of-the-server]__8ecb8e44._.js")
R.c("server/chunks/_next-internal_server_app_api_analyze_route_actions_487cf259.js")
R.m(56811)
module.exports=R.m(56811).exports
