globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/5205f129695d00b3.js",
    "static/chunks/83b9b8edcca63e50.js",
    "static/chunks/d078848a03f02cb3.js",
    "static/chunks/b9cfbaaba1fd82be.js",
    "static/chunks/turbopack-d98eae2912812005.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];